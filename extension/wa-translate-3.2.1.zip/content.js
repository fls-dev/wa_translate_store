(() => {
  'use strict';
  /* ---------- settings ---------- */
  let S = { debug: false, enabled: true, uiLang: 'en', inEnabled: true, inLang: 'en', outEnabled: true, outLang: 'es', outMode: 'review', register: 'casual', chatLang: {}, chatOff: {}, enabledChats: {}, scope: 'selected', engine: 'google', engineLabel: 'google' };
  const stat = { seen: 0, translated: 0, errors: 0, lastEngine: '', lastError: '' };
  const LN = { 'ru':['Russian','🇷🇺'], 'en':['English','🇬🇧'], 'uk':['Ukrainian','🇺🇦'], 'pl':['Polish','🇵🇱'], 'de':['German','🇩🇪'], 'es':['Spanish','🇪🇸'], 'fr':['French','🇫🇷'], 'it':['Italian','🇮🇹'], 'pt':['Portuguese','🇧🇷'], 'tr':['Turkish','🇹🇷'], 'zh-CN':['Chinese','🇨🇳'], 'ja':['Japanese','🇯🇵'], 'ko':['Korean','🇰🇷'], 'ar':['Arabic','🇸🇦'], 'hi':['Hindi','🇮🇳'], 'vi':['Vietnamese','🇻🇳'], 'id':['Indonesian','🇮🇩'], 'nl':['Dutch','🇳🇱'], 'cs':['Czech','🇨🇿'], 'ka':['Georgian','🇬🇪'], 'kk':['Kazakh','🇰🇿'], 'az':['Azerbaijani','🇦🇿'], 'hy':['Armenian','🇦🇲'], 'he':['Hebrew','🇮🇱'], 'th':['Thai','🇹🇭'] };
  const LN_RU = { 'ru':'Русский', 'en':'Английский', 'uk':'Украинский', 'pl':'Польский', 'de':'Немецкий', 'es':'Испанский', 'fr':'Французский', 'it':'Итальянский', 'pt':'Португальский', 'tr':'Турецкий', 'zh-CN':'Китайский', 'ja':'Японский', 'ko':'Корейский', 'ar':'Арабский', 'hi':'Хинди', 'vi':'Вьетнамский', 'id':'Индонезийский', 'nl':'Нидерландский', 'cs':'Чешский', 'ka':'Грузинский', 'kk':'Казахский', 'az':'Азербайджанский', 'hy':'Армянский', 'he':'Иврит', 'th':'Тайский' };
  const T = (s, ...a) => WAT_I18N.t(s, ...a);
  const lname = c => (WAT_I18N.lang === 'ru' && LN_RU[c]) || (LN[c] || [c, '🌐'])[0];
  const lflag = c => (LN[c] || [c, '🌐'])[1];
  const SKIP_RE = /^[\s\d\p{P}\p{S}\p{Extended_Pictographic}\u200d\ufe0f]*$/u;
  const URL_ONLY_RE = /^\s*(https?:\/\/\S+|www\.\S+)(\s+(https?:\/\/\S+|www\.\S+))*\s*$/i;
  const shouldSkip = t => !t || !t.trim() || SKIP_RE.test(t) || URL_ONLY_RE.test(t);
  const send = msg => new Promise(res => {
    try { chrome.runtime.sendMessage(msg, r => res(chrome.runtime.lastError || !r ? { ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || T('no response') } : r)); }
    catch (e) { res({ ok: false, error: String(e) }); }
  });
  const $el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const IC = {
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6.500A2.500 2.500 0 0 1 7.500 4H15"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.500l4.500 4.500L19 7.500"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.600-7 10-7 10 7 10 7-3.600 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.600" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.800" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>',
    tr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.900" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v2M4 6h12M7 10l5 6M13 10l-6 6M15 20l3.500-8 3.500 8M16.200 17.500h4.600"/></svg>'
  };

  /* ---------- WhatsApp theme ---------- */
  function applyTheme() {
    const de = document.documentElement, b = document.body;
    const dark = de.classList.contains('dark') || (b && b.classList.contains('dark'));
    const light = de.classList.contains('light') || (b && b.classList.contains('light'));
    const t = dark ? 'dark' : light ? 'light' : (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    if (de.getAttribute('data-wat-theme') !== t) de.setAttribute('data-wat-theme', t);
  }
  applyTheme();
  new MutationObserver(applyTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
  if (document.body) new MutationObserver(applyTheme).observe(document.body, { attributes: true, attributeFilter: ['class'] });

  /* ---------- engine names ---------- */
  const FAM = { anthropic: '#e8845f', claude: '#e8845f', openai: '#19c39a', gpt: '#19c39a', gemini: '#6b8cff', xai: '#9aa4ad', grok: '#9aa4ad', openrouter: '#7b7ff5', deepl: '#3b82c4', google: '#5b9bff' };
  function pretty(model) {
    const toks = model.split('/').pop().split('-').filter(t => !/^\d{4}$/.test(t));
    const out = []; 
    for (const t of toks) {
      if (/^\d+$/.test(t) && out.length && /^\d+(\.\d+)*$/.test(out[out.length - 1])) out[out.length - 1] += '.' + t;
      else if (/^gpt$/i.test(t)) out.push('GPT');
      else out.push(/^\d/.test(t) ? t : t[0].toUpperCase() + t.slice(1));
    }
    return out.join(' ').replace(/^GPT (\d)/, 'GPT-$1');
  }
  function engInfo(label) {
    label = String(label || '').replace(/\s*\(cache\)\s*/, '').replace(/\s*\(fallback\)\s*/, '');
    const i = label.indexOf(':'), fam = (i < 0 ? label : label.slice(0, i)).trim();
    const name = i < 0 ? ({ google: 'Google', deepl: 'DeepL' }[fam] || fam) : pretty(label.slice(i + 1));
    return { name, color: FAM[fam] || '#25d366' };
  }

  /* ---------- config ---------- */
  let lastCfgKey = '';
  async function loadCfg() {
    const r = await send({ type: 'cfg' });
    if (r.ok) { S = { ...S, ...r.cfg }; WAT_I18N.lang = S.uiLang === 'ru' ? 'ru' : 'en'; scan(); syncHeader(); renderDiag(); }
  }
  loadCfg();
  chrome.storage.onChanged.addListener(ch => { if (Object.keys(ch).some(k => k !== 'watCache' && k !== 'stats')) loadCfg(); });
  const mainEl = () => document.querySelector('#main');
  const firstTitle = h => {
    if (!h) return '';
    const cands = [...h.querySelectorAll('[data-testid="conversation-info-header-chat-title"], span[title], [title], span[dir="auto"]')].filter(e => !e.closest('.wat-hdr'));
    for (const e of cands) { const t = (e.getAttribute('title') || e.textContent || '').trim(); if (t) return t; }
    return '';
  };
  const chatTitle = () => {
    const m = mainEl();
    let t = firstTitle((m && m.querySelector('header')) || document.querySelector('[data-testid="conversation-header"]'));
    if (!t) { const s = document.querySelector('#pane-side [aria-selected="true"] span[title]'); t = s ? (s.getAttribute('title') || '').trim() : ''; }
    return t;
  };
  // Идентификатор чата. Старый WhatsApp кладёт jid в data-id (true_39333@c.us_ID, @g.us, @lid); новый — только id сообщения,
  // тогда единственный ключ — заголовок. Ключей может быть два (jid + «title:Имя»); проверяем любой, чтобы не терять включённость.
  const JID_RE = /^(?:true|false)_([^_\s]+@[a-z.]+)_/i;
  function chatJid() {
    const m = mainEl(); if (!m) return '';
    for (const r of m.querySelectorAll('[data-id]')) { const x = JID_RE.exec(r.getAttribute('data-id') || ''); if (x) return x[1]; }
    const a = m.querySelector('[data-jid], [data-chat-id]');
    const v = a && (a.getAttribute('data-jid') || a.getAttribute('data-chat-id')) || '';
    return /^[^_\s]+@[a-z.]+$/i.test(v) ? v : '';
  }
  function chatKeys() { const j = chatJid(), t = chatTitle(); return [j, t ? 'title:' + t : ''].filter(Boolean); }
  const chatId = () => chatKeys()[0] || '';
  const nameOf = v => (typeof v === 'string' ? v : '');
  const keyIn = m => { if (!m) return null; for (const k of chatKeys()) if (m[k]) return k; return null; };
  // Включён ли перевод в текущем чате: режим «выбранные» — белый список; «все» — всё, кроме исключённых
  const chatIsOn = () => { if (!chatKeys().length) return false; return S.scope === 'all' ? !keyIn(S.chatOff) : !!keyIn(S.enabledChats); };
  const active = () => S.enabled && chatIsOn();
  const outLangNow = () => { const k = keyIn(S.chatLang); return (k && S.chatLang[k]) || S.outLang; };
  function setChatOn(on) {
    const id = chatId(), title = chatTitle(), keys = chatKeys(); if (!id) return;
    const f = S.scope === 'all' ? 'chatOff' : 'enabledChats';
    const m = { ...(S[f] || {}) }; keys.forEach(k => delete m[k]);
    if ((S.scope === 'all') ? !on : on) m[id] = title || id;
    S[f] = m; chrome.storage.local.set({ [f]: m });
    syncHeader(); scan();
  }
  // Миграция настроек, привязанных к заголовку чата → к стабильному id (когда id стал известен)
  function migrateChat() {
    const id = chatId(), title = chatTitle(); if (!id || id.startsWith('title:') || !title) return;
    const patch = {}, tk = 'title:' + title;
    for (const f of ['chatLang', 'chatOff', 'enabledChats']) {
      const m = S[f]; if (!m) continue;
      let ch = false; const n = { ...m };
      for (const k of [title, tk]) if (k in n) { if (!(id in n)) n[id] = f === 'chatLang' ? n[k] : (nameOf(n[k]) || title); delete n[k]; ch = true; }
      if (ch) { patch[f] = n; S[f] = n; }
    }
    if (Object.keys(patch).length) chrome.storage.local.set(patch);
  }

  /* ---------- chat parsing (robust to WhatsApp layout changes) ---------- */
  // Современный WhatsApp Web: у строки только «голый» data-id, нет классов selectable-text / message-in,
  // текст лежит в span[dir], рядом data-pre-plain-text. Поэтому — три яруса поиска текста и несколько способов определить «входящее».
  const SPAN_SEL = 'span.selectable-text, span[data-testid="selectable-text"]';
  const QUOTE_SEL = '[data-testid="quoted-message"], .quoted-mention, [aria-label^="Quoted"], [aria-label^="Цитата"], [aria-label*="Quoted message"]';
  const NOISE_SEL = '.wat-box, .wat-card, .wat-pop, .wat-diag, footer, header, [contenteditable="true"], button';
  const TIME_RE = /^\s*\d{1,2}[:.]\d{2}(\s?[ap]\.?m\.?)?\s*$/i;
  const nodeText = n => {
    let out = '';
    const w = document.createTreeWalker(n, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, { acceptNode: x => x.nodeType === 1 && x.classList && x.classList.contains('wat-box') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    for (let x = w.nextNode(); x; x = w.nextNode()) {
      if (x.nodeType === 3) out += x.nodeValue;
      else if (x.tagName === 'IMG') out += x.getAttribute('alt') || x.getAttribute('data-plain-text') || '';
      else if (x.tagName === 'BR' && x.nextSibling) out += '\n';
    }
    return out;
  };
  const textOf = sp => nodeText(sp).replace(/\u200b/g, '').trim();
  const usable = sp => sp && !sp.closest(NOISE_SEL) && !sp.closest(QUOTE_SEL);
  function longestSpan(root) {
    let best = null, bl = 0;
    for (const s of root.querySelectorAll('span[dir], div[dir="ltr"], div[dir="rtl"]')) {
      if (!usable(s)) continue;
      const t = textOf(s); if (!t || TIME_RE.test(t) || t.length <= bl) continue;
      best = s; bl = t.length;
    }
    return best;
  }
  const rowOf = sp => {
    let r = sp.closest('[data-id]') || sp.closest('[role="row"]') || sp.closest('.message-in, .message-out');
    if (!r) { r = sp; for (let i = 0; i < 6 && r.parentElement && r.parentElement.id !== 'main'; i++) r = r.parentElement; }
    return r;
  };
  const TICK_RE = /^\s*(read|delivered|sent|pending|прочитано|доставлено|отправлено|leído|entregado|enviado|gelesen|zugestellt|gesendet|lu|distribué|envoyé)\s*$/i;
  // Геометрия: «пузырь» — самый верхний предок текста, который заметно уже строки сообщения; входящие прижаты влево, исходящие вправо.
  function geomSide(sp, row) {
    const ref = (sp.closest('[role="row"]') || row).getBoundingClientRect(); if (ref.width < 200) return null;
    let el = sp, best = sp;
    while (el && el.parentElement && el !== row && !el.matches('#main')) { if (el.getBoundingClientRect().width <= ref.width * 0.9) best = el; el = el.parentElement; }
    const r = best.getBoundingClientRect(); if (!r.width) return null;
    const l = r.left - ref.left, rt = ref.right - r.right;
    return l - rt > 40 ? 'me' : rt - l > 40 ? 'them' : null;
  }
  // кто автор: data-id (старый формат) → класс message-in/out → иконки доставки → геометрия пузыря
  function dirOf(sp, row) {
    const idEl = row.hasAttribute && row.hasAttribute('data-id') ? row : row.querySelector && row.querySelector('[data-id]');
    const x = /^(true|false)_/.exec((idEl && idEl.getAttribute('data-id')) || '');
    if (x) return [x[1] === 'true' ? 'me' : 'them', 'data-id'];
    if (row.closest('.message-out') || row.querySelector('.message-out')) return ['me', 'class'];
    if (row.closest('.message-in') || row.querySelector('.message-in')) return ['them', 'class'];
    if (row.querySelector('[data-icon^="msg-"], [data-icon*="dblcheck"], [data-testid="msg-time"]')) return ['me', 'ticks'];
    for (const a of row.querySelectorAll('[aria-label]')) if (TICK_RE.test(a.getAttribute('aria-label') || '')) return ['me', 'ticks'];
    const g = geomSide(sp, row); if (g) return [g, 'geometry'];
    return ['them', 'default'];
  }
  const diag = { rows: 0, them: 0, me: 0, tiers: {}, dirs: {}, lastErr: '', out: '', key: '' };
  function chatRows() {
    const m = mainEl(); if (!m) return [];
    const found = new Map();   // span → tier
    const add = (sp, tier) => { if (!usable(sp) || found.has(sp)) return; for (const o of found.keys()) if (o.contains(sp) || sp.contains(o)) return; found.set(sp, tier); };
    m.querySelectorAll(SPAN_SEL).forEach(sp => { if (!(sp.parentElement && sp.parentElement.closest('span.selectable-text'))) add(sp, 1); });
    m.querySelectorAll('[data-pre-plain-text]').forEach(b => { if ([...found.keys()].some(o => b.contains(o) || o.contains(b))) return; const s = longestSpan(b); if (s) add(s, 2); });
    m.querySelectorAll('[data-id]').forEach(r => { if (r.closest('.wat-box') || [...found.keys()].some(o => r.contains(o) || o.contains(r))) return; const s = longestSpan(r); if (s) add(s, 3); });
    const out = [], tiers = {}, dirs = {};
    [...found.keys()].sort((a, b) => (a.compareDocumentPosition(b) & 4) ? -1 : 1).forEach(sp => {
      const text = textOf(sp); if (!text) return;
      const row = rowOf(sp), [who, how] = dirOf(sp, row);
      tiers[found.get(sp)] = (tiers[found.get(sp)] || 0) + 1; dirs[how] = (dirs[how] || 0) + 1;
      out.push({ who, span: sp, text, row });
    });
    Object.assign(diag, { rows: out.length, them: out.filter(r => r.who === 'them').length, me: out.filter(r => r.who === 'me').length, tiers, dirs });
    return out;
  }
  // куда вставлять перевод: блок с текстом (data-pre-plain-text / copyable-text), иначе ближайший блочный предок
  function holderOf(sp) {
    let h = sp.closest('[data-pre-plain-text], div.copyable-text');
    if (h && h.contains(sp) && !h.closest('.wat-box')) return h;
    h = sp; while (h.parentElement && /^inline/.test(getComputedStyle(h).display)) h = h.parentElement;
    return h;
  }
  const boxOf = sp => { const h = holderOf(sp), n = h && h.nextElementSibling; return n && n.classList && n.classList.contains('wat-box') ? n : null; };
  function ensureBox(sp) {
    let box = boxOf(sp);
    if (!box) { const h = holderOf(sp); if (!h || !h.parentElement) return null; box = $el('div', 'wat-box'); h.insertAdjacentElement('afterend', box); }
    box._wsp = sp;
    return box;
  }
  const removeBox = sp => { const b = boxOf(sp); if (b) b.remove(); };

  /* ---------- incoming ---------- */
  const collapsed = new Set();  // ключи свёрнутых переводов
  function renderSkeleton(sp) {
    const box = ensureBox(sp); if (!box) return;
    box.className = 'wat-box wat-skel';
    box.innerHTML = '<div class="wat-bar"></div><div class="wat-bar"></div><div class="wat-meta">' + T('Translating…') + '</div>';
  }
  function renderError(sp) {
    const box = ensureBox(sp); if (!box) return;
    box.className = 'wat-box';
    box.innerHTML = '<div class="wat-err" data-wat-retry="1">⚠ ' + T('Couldn’t translate') + ' · <u>' + T('retry') + '</u></div>';
  }
  function render(sp, t, src, engine, note) {
    const box = ensureBox(sp); if (!box) return;
    const ei = engInfo(engine), fb = !!note, key = textOf(sp);
    box.className = 'wat-box' + (collapsed.has(key) ? ' wat-collapsed' : '');
    box.innerHTML = '<div class="wat-txt"></div><div class="wat-meta"></div>';
    box.querySelector('.wat-txt').textContent = t;
    const meta = box.querySelector('.wat-meta');
    const badge = $el('span', 'wat-badge' + (fb ? ' wat-fb' : ''), '<i></i>' + (fb ? '⚠ ' : '') + esc(ei.name));
    badge.style.setProperty('--wat-dot', ei.color);
    badge.title = fb ? T('Main engine failed: {0}. Translated by Google fallback.').replace('{0}', note) : T('Translated by {0}').replace('{0}', ei.name);
    meta.appendChild(badge);
    meta.appendChild($el('span', 'wat-lang', (src && src !== '?' ? esc(src) + ' → ' : '→ ') + esc(S.inLang)));
    meta.appendChild($el('span', 'wat-sp'));
    meta.appendChild($el('span', 'wat-showhint', T('Show translation'))).style.display = collapsed.has(key) ? '' : 'none';
    const cp = $el('span', 'wat-ib', IC.copy); cp.title = T('Copy translation'); cp.setAttribute('data-wat-copy', '1'); meta.appendChild(cp);
    const tg = $el('span', 'wat-ib', IC.eye); tg.title = T('Hide / show translation'); tg.setAttribute('data-wat-toggle', '1'); meta.appendChild(tg);
  }
  document.addEventListener('click', e => {
    const box = e.target.closest && e.target.closest('.wat-box'); if (!box) return;
    e.stopPropagation();
    const sp = box._wsp || null;
    if (e.target.closest('[data-wat-retry]')) { if (sp) { sp.removeAttribute('data-wat'); sp.__watErr = 0; } scan(); return; }
    if (e.target.closest('[data-wat-copy]')) {
      const t = box.querySelector('.wat-txt'); if (t) navigator.clipboard.writeText(t.textContent).catch(() => {});
      const b = e.target.closest('[data-wat-copy]'); b.innerHTML = IC.check; b.style.color = 'var(--wat-acc)'; b.style.opacity = 1;
      setTimeout(() => { b.innerHTML = IC.copy; b.style.color = ''; b.style.opacity = ''; }, 1300); return;
    }
    if (window.getSelection && String(window.getSelection()).length) return; // выделяет текст — не сворачиваем
    const key = sp ? textOf(sp) : '';
    box.classList.toggle('wat-collapsed'); const c = box.classList.contains('wat-collapsed');
    if (c) collapsed.add(key); else collapsed.delete(key);
    const h = box.querySelector('.wat-showhint'); if (h) h.style.display = c ? '' : 'none';
  }, true);

  function resetIncoming() {
    document.querySelectorAll('.wat-box').forEach(n => n.remove());
    document.querySelectorAll('[data-wat]').forEach(n => { n.removeAttribute('data-wat'); n.__watLast = null; });
  }
  let scanning = false, again = false;
  async function runScan() {
    migrateChat();
    const ck = [S.enabled, S.inEnabled, S.inLang, S.engine, chatId(), chatIsOn()].join('|');
    if (ck !== lastCfgKey) { lastCfgKey = ck; resetIncoming(); }
    if (!S.inEnabled || !active()) return;
    if (scanning) { again = true; return; }
    scanning = true;
    try {
      const rows = chatRows(), todoIdx = [];
      rows.forEach((r, i) => {
        if (r.who !== 'them') return;
        const key = S.inLang + '|' + S.engine + '|' + r.text;
        if (r.span.getAttribute('data-wat') === key) {
          if (!boxOf(r.span) && r.span.__watLast) render(r.span, r.span.__watLast.t, r.span.__watLast.src, r.span.__watLast.engine, r.span.__watLast.note);
          return;
        }
        if (r.span.__watErr && Date.now() - r.span.__watErr < 30000) return;
        r.span.setAttribute('data-wat', key);
        stat.seen++;
        if (shouldSkip(r.text)) return;
        todoIdx.push(i);
      });
      todoIdx.forEach(i => renderSkeleton(rows[i].span));
      for (let c = 0; c < todoIdx.length; c += 15) {
        const chunk = todoIdx.slice(c, c + 15);
        const from = Math.max(0, chunk[0] - 6), to = chunk[chunk.length - 1], set = new Set(chunk), payload = [];
        for (let i = from; i <= to; i++) payload.push({ n: i, who: rows[i].who, text: rows[i].text, tr: set.has(i) });
        const r = await send({ type: 'incoming', tl: S.inLang, rows: payload });
        if (!r.ok) { stat.errors++; stat.lastError = r.error || ''; chunk.forEach(i => { rows[i].span.removeAttribute('data-wat'); rows[i].span.__watErr = Date.now(); renderError(rows[i].span); }); continue; }
        stat.lastEngine = r.engine; stat.lastError = r.note || '';
        const got = new Map(r.results);
        for (const i of chunk) {
          const row = rows[i], v = got.get(i);
          if (!v || !v.t || !v.t.trim() || v.t.trim() === row.text.trim()) { removeBox(row.span); continue; }
          stat.translated++;
          row.span.__watLast = { t: v.t, src: v.src, engine: r.engine, note: r.note };
          render(row.span, v.t, v.src, r.engine, r.note);
        }
      }
    } finally { scanning = false; if (again) { again = false; scan(); } }
  }
  let timer = null;
  function scan() { if (timer) return; timer = setTimeout(() => { timer = null; runScan().catch(() => {}); syncHeader(); }, 400); }
  new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true });
  setInterval(scan, 4000);

  /* ---------- outgoing ---------- */
  // WhatsApp Web — редактор Lexical: DOM для него только «вывод», отправляется внутренняя модель.
  // Поэтому текст вставляем событием paste (Lexical обрабатывает его штатно), проверяем результат и только потом жмём настоящую кнопку отправки.
  let lastTranslated = null, pend = null, cardEl = null, cardTimer = null, busy = false, selfClick = false, eatEnter = false;
  const COMPOSER_SELS = [
    'footer div[contenteditable]:not([contenteditable="false"])[data-lexical-editor="true"]',
    'footer div[contenteditable]:not([contenteditable="false"])[role="textbox"]',
    'footer div[contenteditable]:not([contenteditable="false"])[data-tab]',
    '#main div[contenteditable]:not([contenteditable="false"])[role="textbox"]',
    'footer div[contenteditable]:not([contenteditable="false"])'
  ];
  const composer = () => { for (const s of COMPOSER_SELS) { const e = document.querySelector(s); if (e) return e; } return null; };
  const SEND_SEL = 'button[aria-label="Send"], button[aria-label="Отправить"], [data-icon="send"], [data-icon="wds-ic-send-filled"], [data-icon*="send"], [data-testid="send"]';
  const findSend = () => {
    const root = document.querySelector('footer') || mainEl() || document;
    const b = root.querySelector(SEND_SEL); return b ? (b.closest('button, [role="button"]') || b) : null;
  };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const raf2 = () => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
  const norm = s => String(s || '').replace(/[\u200b\u200c\ufeff]/g, '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  function composerText(el) {
    const blocks = [...el.children].filter(c => /^(P|DIV)$/.test(c.tagName));
    const lines = blocks.length ? blocks.map(b => { let t = nodeText(b); return t; }) : [nodeText(el)];
    return lines.join('\n').replace(/\u200b/g, '').replace(/\n+$/, '');
  }
  function selectAllIn(el) {
    el.focus();
    const sel = getSelection(), r = document.createRange(); r.selectNodeContents(el); sel.removeAllRanges(); sel.addRange(r);
  }
  // Перенос строки так же, как делает пользователь (Shift+Enter): Lexical обрабатывает это штатно.
  function lineBreak(el, method) {
    if (method === 'paste' || method === 'pasteAll') el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, shiftKey: true, bubbles: true, cancelable: true }));
    else if (method === 'beforeinput') el.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertLineBreak', bubbles: true, cancelable: true }));
    else document.execCommand('insertLineBreak');
  }
  // Строки вставляем по одной, между ними — настоящий перенос строки (как Shift+Enter), чтобы не появлялись пустые абзацы.
  async function tryInsert(el, text, method) {
    const lines = method === 'pasteAll' ? [text] : text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      if (i > 0) { lineBreak(el, method); await raf2(); }
      const ln = lines[i]; if (!ln) continue;
      if (method === 'paste' || method === 'pasteAll') {
        const dt = new DataTransfer(); dt.setData('text/plain', ln);
        el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
      } else if (method === 'insertText') document.execCommand('insertText', false, ln);
      else el.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertFromPaste', data: ln, bubbles: true, cancelable: true }));
      if (lines.length > 1) await raf2();
    }
  }
  // Заменяет всё содержимое поля текстом и ПРОВЕРЯЕТ, что он там действительно оказался.
  async function writeComposer(el, text) {
    const want = norm(text); diag.att = '';
    for (const method of ['paste', 'insertText', 'beforeinput', 'pasteAll']) {
      try {
        selectAllIn(el); await raf2();     // дать Lexical принять выделение (selectionchange асинхронный)
        await tryInsert(el, text, method);
        await raf2(); await sleep(60);
        diag.att = (diag.att || '') + method + ':' + norm(composerText(el)).length + '/' + want.length + ' ';
        if (norm(composerText(el)) === want) { await sleep(60); if (norm(composerText(el)) === want) { diag.out = 'paste: ' + method + ' ok'; return { ok: true, method }; } }
      } catch (e) { diag.lastErr = 'insert ' + method + ': ' + e; }
    }
    diag.out = 'paste failed'; return { ok: false };
  }
  // Кладёт текст в поле (если ещё не там), проверяет, жмёт настоящую кнопку «Отправить», ждёт очистки поля.
  async function commitSend(el, text) {
    busy = true;
    try {
      if (norm(composerText(el)) !== norm(text)) {
        const w = await writeComposer(el, text);
        if (!w.ok) return { ok: false, error: T('Couldn’t insert the translation into the WhatsApp box — nothing was sent. The translation is on your clipboard: paste it with Ctrl+V.') };
      }
      await raf2(); await sleep(80);
      if (norm(composerText(el)) !== norm(text)) return { ok: false, error: T('The message box changed during the paste — nothing was sent. The translation is on your clipboard.') };
      let btn = null;
      for (let i = 0; i < 25 && !(btn = findSend()); i++) await sleep(80);
      if (!btn) return { ok: false, error: T('Send button not found (WhatsApp changed its layout) — nothing was sent. The translation is on your clipboard.') };
      selfClick = true; try { btn.click(); } finally { selfClick = false; }
      busy = false;   // дальше только наблюдаем, пользователь уже может печатать
      for (let i = 0; i < 50; i++) { await sleep(40); if (norm(composerText(el)) !== norm(text)) { diag.out += ' · sent ok'; return { ok: true }; } }
      diag.out += ' · send not confirmed';
      return { ok: true, unsure: true };
    } finally { busy = false; }
  }
  function toast(msg, bad, ok) {
    document.querySelectorAll('.wat-toast').forEach(t => t.remove());
    const t = $el('div', 'wat-toast' + (bad ? ' bad' : ''), (ok ? '<span class="ck">' + IC.check + '</span>' : '') + esc(msg));
    document.body.appendChild(t); setTimeout(() => t.remove(), bad ? 6000 : 2200);
  }
  function placeCard() {
    if (!cardEl) return;
    const f = document.querySelector('footer'); const r = f ? f.getBoundingClientRect() : { left: 20, width: innerWidth - 40, top: innerHeight - 70 };
    const w = Math.min(Math.max(r.width - 28, 280), 660);
    cardEl.style.width = w + 'px'; cardEl.style.left = Math.round(r.left + 14) + 'px'; cardEl.style.bottom = Math.round(innerHeight - r.top + 10) + 'px';
  }
  function hideCard(immediate) {
    clearInterval(cardTimer); const c = cardEl; cardEl = null;
    if (!c) return;
    if (immediate) c.remove(); else { c.classList.add('wat-out'); setTimeout(() => c.remove(), 180); }
  }
  function renderCard() {
    if (!pend) return hideCard();
    const fresh = !cardEl;
    if (fresh) { cardEl = $el('div', 'wat-card'); document.body.appendChild(cardEl); cardTimer = setInterval(placeCard, 300); }
    const ei = engInfo(pend.engine || S.engineLabel), fb = !!pend.note;
    cardEl.classList.toggle('wat-cerr', !!pend.error);
    let body;
    if (pend.fatal) body = `<div class="wat-cerrtxt">${esc(pend.error)}</div>`;
    else if (pend.error) body = `<div class="wat-cerrtxt">${T('Couldn’t translate:')} ${esc(pend.error)}</div>`;
    else if (pend.loading) body = '<div class="wat-skel"><div class="wat-bar"></div><div class="wat-bar"></div></div>';
    else body = `<div class="wat-ct">${esc(pend.text)}</div>`;
    const foot = pend.fatal
      ? `<button class="wat-btn pri" data-wat-c="copy">${T('Copy translation')}</button><button class="wat-btn" data-wat-c="cancel">${T('Close')} <kbd>Esc</kbd></button>`
      : pend.error
      ? `<button class="wat-btn pri" data-wat-c="sendorig">${T('Send as is')} <kbd>Enter</kbd></button><button class="wat-btn" data-wat-c="cancel">${T('Edit')} <kbd>Esc</kbd></button>`
      : `<button class="wat-btn pri" data-wat-c="send" ${pend.loading ? 'disabled style="opacity:.5"' : ''}>${T('Send')} <kbd>Enter</kbd></button><button class="wat-btn" data-wat-c="edit" ${pend.loading ? 'disabled style="opacity:.5"' : ''}>${T('Edit')}</button><button class="wat-btn" data-wat-c="cancel">${T('Cancel')} <kbd>Esc</kbd></button>`;
    cardEl.innerHTML = `<div class="wat-ch"><span class="wat-badge${fb ? ' wat-fb' : ''}" style="--wat-dot:${ei.color}"><i></i>${fb ? '⚠ ' : ''}${esc(ei.name)}</span><span>${lflag(pend.tl)} ${esc(lname(pend.tl))} · ${S.register === 'business' ? T('business') : T('casual')}</span><span class="wat-x" data-wat-c="cancel">${IC.x}</span></div>${body}${pend.error || pend.loading ? '' : `<div class="wat-co" data-lbl="${esc(T('Original: '))}">${esc(pend.original)}</div>`}<div class="wat-cf">${foot}</div>`;
    if (fresh) placeCard(); else placeCard();
    if (fb && !pend.error) cardEl.querySelector('.wat-badge').title = T('Main engine failed: {0}. Translated by Google fallback.').replace('{0}', pend.note);
  }
  async function translateDraft(el) {
    const original = composerText(el);
    if (shouldSkip(original)) return false;
    const tl = outLangNow();
    pend = { original, tl, loading: true, engine: S.engineLabel }; renderCard();
    const mine = pend;
    const ctx = chatRows().slice(-8).map(r => ({ who: r.who, text: r.text }));
    const r = await send({ type: 'outgoing', tl, text: original, rows: ctx, register: S.register });
    if (pend !== mine) return false; // отменили, пока ждали
    if (!r.ok) { mine.loading = false; mine.error = r.error || T('error'); diag.lastErr = mine.error; renderCard(); return false; }
    if (r.src && r.src !== 'auto' && r.src.split('-')[0] === tl.split('-')[0]) { pend = null; hideCard(); lastTranslated = norm(original); toast(T('Text is already in {0}').replace('{0}', lname(tl)), false, true); return true; }
    Object.assign(mine, { loading: false, text: r.text, engine: r.engine, note: r.note, src: r.src });
    if (S.outMode === 'instant') { await confirmSend(el, false); return true; }
    renderCard(); return true;
  }
  async function confirmSend(el, asOriginal) {
    const p = pend; if (!p || busy) return;
    const text = asOriginal ? p.original : p.text;
    pend = null; hideCard(true);
    const r = await commitSend(el, text);
    if (!r.ok) {
      diag.lastErr = r.error;
      try { await navigator.clipboard.writeText(text); } catch (e) {}
      if (!asOriginal) await writeComposer(el, p.original);   // вернуть исходный текст, чтобы ничего не потерялось
      pend = { ...p, loading: false, error: r.error, fatal: true, text }; renderCard(); return;
    }
    lastTranslated = null;
    if (r.unsure) toast(T('Couldn’t confirm the message was sent — check the chat'), true);
    else if (!asOriginal) toast(T('Sent → {0}').replace('{0}', lname(p.tl)), false, true);
  }
  async function editTranslation(el) {
    const p = pend; pend = null; hideCard();
    const w = await writeComposer(el, p.text);
    if (!w.ok) { try { await navigator.clipboard.writeText(p.text); } catch (e) {} diag.lastErr = 'edit: paste failed'; toast(T('Couldn’t insert into the box — the translation is on the clipboard (Ctrl+V)'), true); return; }
    lastTranslated = norm(composerText(el)); el.focus();
  }
  document.addEventListener('mousedown', e => { if (e.target.closest && e.target.closest('.wat-card')) e.preventDefault(); }, true);
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-wat-c]'); if (!b || !pend) return;
    e.stopPropagation(); const el = composer(), a = b.getAttribute('data-wat-c');
    if (a === 'cancel') { pend = null; hideCard(); if (el) el.focus(); }
    else if (a === 'copy') { navigator.clipboard.writeText(pend.text || pend.original).catch(() => {}); toast(T('Copied'), false, true); }
    else if (a === 'send' && el && !pend.loading) confirmSend(el, false);
    else if (a === 'sendorig' && el) confirmSend(el, true);
    else if (a === 'edit' && el && !pend.loading) editTranslation(el);
  }, true);

  // Что делать с «намерением отправить» (Enter или клик по кнопке): 'pass' — пусть WhatsApp делает сам, 'swallow' — подавить, 'handle' — наша логика.
  function sendIntent(el) {
    if (busy) return 'swallow';
    if (pend) {
      if (pend.loading || pend.fatal) return 'swallow';
      if (pend.error) return 'handle';
      if (norm(composerText(el)) === norm(pend.original)) return 'handle';
      pend = null; hideCard();
    }
    if (!S.outEnabled) return 'pass';
    const cur = composerText(el);
    if (!cur.trim()) return 'pass';
    if (lastTranslated !== null && norm(cur) === lastTranslated) { lastTranslated = null; return 'pass'; }
    if (shouldSkip(cur)) return 'pass';
    return 'handle';
  }
  async function runIntent(el) {
    if (pend && pend.error && !pend.fatal) return confirmSend(el, true);
    if (pend && !pend.loading && !pend.error) return confirmSend(el, false);
    return translateDraft(el);
  }
  // Ловим на window в фазе capture — раньше обработчиков WhatsApp/Lexical.
  window.addEventListener('keydown', e => {
    const el = composer();
    if (!el || (e.target !== el && !el.contains(e.target))) return;
    if (!active()) return;
    if (e.key === 'Escape') { if (pend) { e.preventDefault(); e.stopPropagation(); pend = null; hideCard(); } lastTranslated = null; return; }
    if (e.altKey && e.code === 'KeyT') { e.preventDefault(); e.stopImmediatePropagation(); if (!pend && !busy) translateDraft(el); return; }
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing || e.keyCode === 229 || e.ctrlKey || e.metaKey || e.altKey) return;
    const d = sendIntent(el); diag.key = d + ' (busy=' + busy + ', pend=' + (pend ? (pend.loading ? 'loading' : pend.fatal ? 'fatal' : pend.error ? 'error' : 'ready') : 'none') + ', last=' + (lastTranslated !== null) + ')';
    if (d === 'pass') return;
    e.preventDefault(); e.stopImmediatePropagation(); eatEnter = true;
    if (d === 'handle') runIntent(el);
  }, true);
  const eat = e => { if (eatEnter && e.key === 'Enter') { e.preventDefault(); e.stopImmediatePropagation(); if (e.type === 'keyup') eatEnter = false; } };
  window.addEventListener('keypress', eat, true); window.addEventListener('keyup', eat, true);
  // Клик по кнопке «Отправить» (мышью) — то же самое
  window.addEventListener('click', e => {
    if (selfClick || !e.target.closest) return;
    const b = e.target.closest(SEND_SEL); if (!b || !b.closest('footer')) return;
    const el = composer(); if (!el || !active()) return;
    const d = sendIntent(el);
    if (d === 'pass') return;
    e.preventDefault(); e.stopImmediatePropagation();
    if (d === 'handle') runIntent(el);
  }, true);
  document.addEventListener('input', () => {
    if (busy) return;
    const el = composer(); if (!el) return;
    const cur = composerText(el);
    if (pend && !pend.fatal && norm(cur) !== norm(pend.original)) { pend = null; hideCard(); }
    if (lastTranslated !== null && norm(cur) !== lastTranslated) lastTranslated = null;
  }, true);

  /* ---------- chat header button (one-click on/off) + language popover ---------- */
  let popEl = null;
  function syncHeader() {
    const h = document.querySelector('#main header'); if (!h) return;
    let w = h.querySelector('.wat-hdr');
    if (!w) {
      w = $el('div', 'wat-hdr', '<button class="wat-hbtn" data-wat-h="toggle">' + IC.tr + '</button><button class="wat-hchev" data-wat-h="menu" title="' + T('Language and chat settings') + '">' + IC.chev + '</button>');
      h.appendChild(w);
      w.addEventListener('click', e => {
        const b = e.target.closest('[data-wat-h]'); if (!b) return; e.stopPropagation(); e.preventDefault();
        if (b.dataset.watH === 'menu') { popEl ? closePop() : openPop(w); return; }
        closePop(); const on = !chatIsOn(); setChatOn(on);
        if (on && !S.enabled) chrome.storage.local.set({ enabled: true });
        toast(on ? T('Translation is on in this chat') : T('Translation is off in this chat'), false, on);
      }, true);
    }
    const on = active(), b = w.querySelector('.wat-hbtn');
    b.classList.toggle('on', on);
    b.title = on ? T('Translation is on in this chat — click to turn off') : T('Translation is off in this chat — click to turn on');
  }
  function closePop() { if (popEl) { popEl.remove(); popEl = null; } }
  function openPop(anchor) {
    const id = chatId(), title = chatTitle(), on = chatIsOn();
    const opts = '<option value="">' + T('Same as default') + '</option>' + Object.keys(LN).map(k => `<option value="${k}" ${keyIn(S.chatLang) && S.chatLang[keyIn(S.chatLang)] === k ? 'selected' : ''}>${LN[k][1]} ${lname(k)}</option>`).join('');
    const ei = engInfo(S.engineLabel);
    popEl = $el('div', 'wat-pop', `
      <div class="wat-ph"><img src="${chrome.runtime.getURL('icons/icon48.png')}" alt=""><div><b>WA Translate</b><span>${esc(ei.name)} · ${S.register === 'business' ? T('business') : T('casual')}</span></div></div>
      <div class="wat-pr"><div class="wat-pl"><b>${T('Translation in this chat')}</b><span>${esc(title || T('chat'))}</span></div><label class="wat-sw"><input type="checkbox" data-p="chat" ${on ? 'checked' : ''}><i></i></label></div>
      <div class="wat-pr"><div class="wat-pl"><b>${T('Write in')}</b><span>${T('for this chat')}</span></div><select class="wat-sel" data-p="lang">${opts}</select></div>
      <div class="wat-pf">${S.scope === 'all' ? T('Mode: all chats') : T('Mode: selected chats only')} · ${T('Alt+T — translate the draft · settings — the extension icon in the Chrome toolbar')}</div>`);
    document.body.appendChild(popEl);
    const r = anchor.getBoundingClientRect();
    popEl.style.top = Math.round(r.bottom + 6) + 'px'; popEl.style.left = Math.max(8, Math.round(Math.min(r.right - 300, innerWidth - 308))) + 'px';
    popEl.addEventListener('change', e => {
      const p = e.target.getAttribute('data-p');
      if (p === 'chat') setChatOn(e.target.checked);
      else if (p === 'lang') { const m = { ...(S.chatLang || {}) }; chatKeys().forEach(k => delete m[k]); if (e.target.value) m[id] = e.target.value; S.chatLang = m; chrome.storage.local.set({ chatLang: m }); }
    });
  }
  document.addEventListener('click', e => { if (popEl && !e.target.closest('.wat-pop') && !e.target.closest('.wat-hdr')) closePop(); }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closePop(); }, true);

  /* ---------- diagnostics (enabled in the popup) ---------- */
  const SAFE_VAL = new Set(['role', 'dir', 'data-testid', 'data-icon', 'contenteditable', 'data-lexical-editor', 'data-tab', 'type', 'tabindex', 'spellcheck', 'lang', 'aria-selected', 'data-lexical-text']);
  const shape = v => String(v).replace(/[A-Za-z]/g, 'a').replace(/\d/g, '9').replace(/a+/g, 'a').replace(/9+/g, '9');
  const idShape = v => { const m = /^(true|false)_(.+?)(@[a-z.]+)_(.*)$/i.exec(v); return m ? m[1] + '_' + shape(m[2]) + m[3] + '_' + shape(m[4]) : shape(v); };
  const script = t => [/[\u0400-\u04ff]/.test(t) && 'cyr', /[a-z]/i.test(t) && 'lat', /[\u4e00-\u9fff\u3040-\u30ff]/.test(t) && 'cjk', /[\u0600-\u06ff]/.test(t) && 'ar', /\p{Extended_Pictographic}/u.test(t) && 'emoji'].filter(Boolean).join('+') || 'other';
  function sanitize(el, depth, cap) {
    const lines = []; let n = 0;
    (function walk(e, d) {
      if (n++ > cap || d > depth) { if (n === cap + 2) lines.push('  '.repeat(d) + '…'); return; }
      if (e.nodeType === 3) { const t = e.nodeValue.trim(); if (t) lines.push('  '.repeat(d) + '#text(' + t.length + ' chars, ' + script(t) + ')'); return; }
      if (e.nodeType !== 1 || e.classList.contains('wat-box') || e.classList.contains('wat-hdr') || e.classList.contains('wat-diag')) return;
      const at = [...e.attributes].filter(a => a.name !== 'class' && a.name !== 'style').map(a => {
        if (a.name === 'data-id') return 'data-id=' + idShape(a.value);
        if (a.name === 'aria-label') return TICK_RE.test(a.value) ? 'aria-label=' + a.value.trim() : 'aria-label=<' + a.value.length + ' chars>';
        if (SAFE_VAL.has(a.name)) return a.name + '=' + a.value;
        return a.name;
      });
      lines.push('  '.repeat(d) + '<' + e.tagName.toLowerCase() + (e.classList.length ? ' .' + [...e.classList].join('.') : '') + (at.length ? ' [' + at.join('; ') + ']' : '') + '>');
      e.childNodes.forEach(c => walk(c, d + 1));
    })(el, 0);
    return lines.join('\n');
  }
  function buildReport() {
    const m = mainEl(), rows = chatRows(), keys = chatKeys();
    const pick = rows.filter(r => r.who === 'them').sort((a, b) => b.text.length - a.text.length)[0] || rows.sort((a, b) => b.text.length - a.text.length)[0];
    let rowEl = pick && pick.row;
    if (!rowEl && m) rowEl = m.querySelector('[data-id]') || m.querySelector('[role="row"]');
    if (rowEl && rowEl.closest) rowEl = rowEl.closest('[role="row"]') || rowEl;
    const cnt = sel => { try { return (m || document).querySelectorAll(sel).length; } catch (e) { return -1; } };
    const comp = composer(), foot = document.querySelector('footer');
    const hdr = m && m.querySelector('header');
    const chain = []; if (pick) { for (let e = pick.span; e && e !== m && chain.length < 12; e = e.parentElement) chain.push(e.tagName.toLowerCase() + (e.classList.length ? '.' + [...e.classList].slice(0, 4).join('.') : '')); }
    return [
      '=== WA Translate · diagnostics report (no message text) ===',
      'version: ' + chrome.runtime.getManifest().version + ' · ' + new Date().toISOString(),
      'UA: ' + navigator.userAgent,
      'theme: html.' + document.documentElement.className + ' body.' + document.body.className,
      'chat: title ' + (chatTitle() ? '<' + chatTitle().length + ' chars>' : 'NOT FOUND') + ' · jid ' + (chatJid() ? idShape('false_' + chatJid() + '_x').slice(6, -2) : 'none (new data-id format)') + ' · keys: ' + keys.map(k => k.startsWith('title:') ? 'title' : 'jid').join(',') + ' · translation on: ' + chatIsOn() + ' · mode: ' + S.scope + ' · engine: ' + S.engine,
      '#main: ' + !!m + ' · header: ' + !!hdr + ' · footer: ' + !!foot + ' · composer: ' + (comp ? comp.tagName.toLowerCase() + ' lexical=' + comp.hasAttribute('data-lexical-editor') : 'NOT FOUND') + ' · send button: ' + !!findSend(),
      'selectors in #main: [data-id]=' + cnt('[data-id]') + ' [role=row]=' + cnt('[role="row"]') + ' .message-in=' + cnt('.message-in') + ' .message-out=' + cnt('.message-out') + ' span.selectable-text=' + cnt('span.selectable-text') + ' [data-pre-plain-text]=' + cnt('[data-pre-plain-text]') + ' span[dir]=' + cnt('span[dir]') + ' [data-icon^=msg-]=' + cnt('[data-icon^="msg-"]'),
      'messages found: ' + rows.length + ' (incoming ' + diag.them + ', own ' + diag.me + ') · text lookup tiers: ' + JSON.stringify(diag.tiers) + ' · who detected by: ' + JSON.stringify(diag.dirs),
      'translation blocks on page: ' + document.querySelectorAll('.wat-box:not(.wat-skel)').length + ' · translated: ' + stat.translated + ' · errors: ' + stat.errors + ' · last error: ' + (stat.lastError || diag.lastErr || '—'),
      'send: ' + (diag.out || '—') + ' · paste attempts: ' + (diag.att || '—'),
      '', '--- path from message text to #main ---', chain.join(' < ') || '(message not found)',
      '', '--- message row ---', rowEl ? sanitize(rowEl, 14, 220) : '(not found)',
      '', '--- chat header ---', hdr ? sanitize(hdr, 5, 60) : '(none)',
      '', '--- footer / composer ---', foot ? sanitize(foot, 9, 140) : (comp ? sanitize(comp, 6, 60) : '(none)')
    ].join('\n');
  }
  let diagEl = null;
  function renderDiag() {
    if (!S.debug) { if (diagEl) { diagEl.remove(); diagEl = null; } return; }
    if (!diagEl) {
      diagEl = $el('div', 'wat-diag');
      diagEl.addEventListener('click', e => {
        const b = e.target.closest('[data-d]'); if (!b) return; e.stopPropagation();
        if (b.dataset.d === 'copy') { const t = buildReport(); (navigator.clipboard.writeText(t).catch(() => { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); })); toast(T('Report copied — paste it into a chat'), false, true); }
        else if (b.dataset.d === 'off') chrome.storage.local.set({ debug: false });
      }, true);
      document.body.appendChild(diagEl);
    }
    chatRows();
    const err = stat.lastError || diag.lastErr;
    diagEl.innerHTML = `<div class="dh"><b>Diagnostics</b> · v${esc(chrome.runtime.getManifest().version)}<span class="sp"></span><i data-d="off" title="Turn diagnostics off">×</i></div>
      <div>chat: <b>${esc(chatTitle() || '—')}</b></div>
      <div>id: <b>${esc(chatJid() || 'no jid → by name')}</b></div>
      <div>enabled: <b class="${chatIsOn() ? 'ok' : 'no'}">${chatIsOn() ? 'yes' : 'no'}</b> · mode: ${S.scope === 'all' ? 'all chats' : 'selected'}${S.enabled ? '' : ' · <b class="no">extension off</b>'}</div>
      <div>messages found: <b>${diag.rows}</b> (incoming <b>${diag.them}</b>) · translated: <b>${stat.translated}</b></div>
      <div>message box: <b class="${composer() ? 'ok' : 'no'}">${composer() ? 'found' : 'NO'}</b> · send button: <b class="${findSend() ? 'ok' : ''}">${findSend() ? 'yes' : 'no'}</b></div>
      ${diag.out ? `<div>send: ${esc(diag.out)}</div>` : ''}
      ${diag.att ? `<div>paste attempts (got/needed chars): ${esc(diag.att)}</div>` : ''}
      ${diag.key ? `<div>last Enter: ${esc(diag.key)}</div>` : ''}
      <div class="er">${err ? 'error: ' + esc(err) : 'no errors'}</div>
      <button data-d="copy">Copy report</button>`;
  }
  setInterval(() => { if (S.debug || diagEl) renderDiag(); }, 1000);

  chrome.runtime.onMessage.addListener((m, _s, send2) => {
    if (m && m.type === 'stats') send2({ ...stat, chat: chatTitle(), chatId: chatId(), chatOn: chatIsOn(), outLang: outLangNow() });
  });
})();

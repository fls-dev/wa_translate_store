'use strict';
const $ = (s, r = document) => r.querySelector(s);
const T = (s, ...a) => WAT_I18N.t(s, ...a);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------- data ---------- */
const LANGS = [
  ['ru','Русский','Русский','🇷🇺','Russian'],['en','English','Английский','🇬🇧','English'],['uk','Українська','Украинский','🇺🇦','Ukrainian'],['pl','Polski','Польский','🇵🇱','Polish'],
  ['de','Deutsch','Немецкий','🇩🇪','German'],['es','Español','Испанский','🇪🇸','Spanish'],['fr','Français','Французский','🇫🇷','French'],['it','Italiano','Итальянский','🇮🇹','Italian'],
  ['pt','Português','Португальский','🇧🇷','Portuguese'],['tr','Türkçe','Турецкий','🇹🇷','Turkish'],['zh-CN','中文','Китайский','🇨🇳','Chinese'],['ja','日本語','Японский','🇯🇵','Japanese'],
  ['ko','한국어','Корейский','🇰🇷','Korean'],['ar','العربية','Арабский','🇸🇦','Arabic'],['hi','हिन्दी','Хинди','🇮🇳','Hindi'],['vi','Tiếng Việt','Вьетнамский','🇻🇳','Vietnamese'],
  ['id','Indonesia','Индонезийский','🇮🇩','Indonesian'],['nl','Nederlands','Нидерландский','🇳🇱','Dutch'],['cs','Čeština','Чешский','🇨🇿','Czech'],['ka','ქართული','Грузинский','🇬🇪','Georgian'],
  ['kk','Қазақша','Казахский','🇰🇿','Kazakh'],['az','Azərbaycan','Азербайджанский','🇦🇿','Azerbaijani'],['hy','Հայերեն','Армянский','🇦🇲','Armenian'],['he','עברית','Иврит','🇮🇱','Hebrew'],['th','ไทย','Тайский','🇹🇭','Thai']
];
const LANG = Object.fromEntries(LANGS.map(l => [l[0], l]));
const lnm = l => (WAT_I18N.lang === 'ru' ? l[2] : l[4]);
const DEFAULT_MODELS = { openai:'gpt-6-luna', anthropic:'claude-haiku-5-5', gemini:'gemini-3.5-flash-lite', xai:'grok-4.20-0309-non-reasoning', openrouter:'anthropic/claude-haiku-5.5' };

const I = { // иконки
  eye:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>',
  eyeoff:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.4 10.4 0 0 1 12 19c-6.4 0-10-7-10-7a17.6 17.6 0 0 1 4.1-5M9.9 5.2A9.5 9.5 0 0 1 12 5c6.4 0 10 7 10 7a17.7 17.7 0 0 1-2.2 3.2M1 1l22 22"/></svg>',
  check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  x:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  chev:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>',
  search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>'
};
const LOGO = '<img class="logo" src="icons/icon128.png" alt="">';
const W = 'stroke="#fff" fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"';
const ENGINES = [
  { id:'anthropic', name:'Claude', sub:'Haiku 5.5 · Anthropic', tag:'Best pick', price:'≈ $0.07 / 1000', bg:'linear-gradient(135deg,#e8845f,#c9552f)', link:'https://console.anthropic.com/settings/keys', hint:'sk-ant-…',
    svg:`<svg viewBox="0 0 24 24" ${W}><path d="M5 19L11 5h2l6 14M8 14h8"/></svg>` },
  { id:'openai', name:'GPT', sub:'GPT-6 Luna · OpenAI', tag:'Cheap', price:'≈ $0.07 / 1000', bg:'linear-gradient(135deg,#19c39a,#0b8a6c)', link:'https://platform.openai.com/api-keys', hint:'sk-…',
    svg:`<svg viewBox="0 0 24 24" ${W}><ellipse cx="12" cy="12" rx="4" ry="8.5"/><ellipse cx="12" cy="12" rx="4" ry="8.5" transform="rotate(60 12 12)"/><ellipse cx="12" cy="12" rx="4" ry="8.5" transform="rotate(120 12 12)"/></svg>` },
  { id:'gemini', name:'Gemini', sub:'3.5 Flash-Lite · Google', tag:'Free', price:'$0 · ~500/day', bg:'linear-gradient(135deg,#4f8cff,#9b6bff)', link:'https://aistudio.google.com/apikey', hint:'AIza…',
    svg:'<svg viewBox="0 0 24 24"><path fill="#fff" d="M12 2c.6 6 4 9.4 10 10-6 .6-9.400 4-10 10-.6-6-4-9.400-10-10 6-.6 9.400-4 10-10z"/></svg>' },
  { id:'xai', name:'Grok', sub:'4.20 · xAI', tag:'', price:'≈ $0.7 / 1000', bg:'linear-gradient(135deg,#3a3f46,#0d0f12)', link:'https://console.x.ai', hint:'xai-…',
    svg:`<svg viewBox="0 0 24 24" ${W}><circle cx="12" cy="12" r="7.6"/><path d="M6.5 17.500L17.500 6.500"/></svg>` },
  { id:'openrouter', name:'OpenRouter', sub:'one key — any model', tag:'', price:'per model', bg:'linear-gradient(135deg,#7b7ff5,#4b4fd8)', link:'https://openrouter.ai/keys', hint:'sk-or-…',
    svg:`<svg viewBox="0 0 24 24" ${W}><path d="M3 8h5c5 0 3 8 8 8h4M17 13l3 3-3 3M3 16h5c1.500 0 2.500-.700 3.300-1.800"/></svg>` },
  { id:'deepl', name:'DeepL', sub:'500k characters free', tag:'', price:'$0 (Free)', bg:'linear-gradient(135deg,#1b4a78,#0d2740)', link:'https://www.deepl.com/pro-api', hint:'…:fx',
    svg:`<svg viewBox="0 0 24 24" ${W}><path d="M7 5h5a7 7 0 0 1 0 14H7zM7 10h5M7 14h5"/></svg>` },
  { id:'google', name:'Google Translate', sub:'no key · literal', tag:'', price:'$0', bg:'linear-gradient(135deg,#5b9bff,#2a64d6)', link:'', hint:'',
    svg:`<svg viewBox="0 0 24 24" ${W}><path d="M12 3v2M4 6h12M7 10l5 6M13 10l-6 6M15 20l3.500-8 3.500 8M16.200 17.500h4.600"/></svg>` }
];
const ENG = Object.fromEntries(ENGINES.map(e => [e.id, e]));
const icoHtml = e => `<div class="eico" style="background:${e.bg}">${e.svg}</div>`;

function pretty(model) {
  const out = [];
  for (const t of model.split('/').pop().split('-').filter(t => !/^\d{4}$/.test(t))) {
    if (/^\d+$/.test(t) && out.length && /^\d+(\.\d+)*$/.test(out[out.length - 1])) out[out.length - 1] += '.' + t;
    else if (/^gpt$/i.test(t)) out.push('GPT'); else out.push(/^\d/.test(t) ? t : t[0].toUpperCase() + t.slice(1));
  }
  return out.join(' ').replace(/^GPT (\d)/, 'GPT-$1');
}
const engName = id => { const i = String(id).indexOf(':'); return i < 0 ? ({ google: 'Google', deepl: 'DeepL' }[id] || id) : pretty(id.slice(i + 1)); };
/* ---------- state ---------- */
const D = { enabled:true, onboarded:false, uiLang:'en', engine:'google', fallback:true, keys:{}, models:{}, register:'casual', inEnabled:true, inLang:'en', outEnabled:true, outLang:'es', outMode:'review', chatLang:{}, chatOff:{}, enabledChats:{}, scope:'selected', debug:false };
let cfg = { ...D }, stats = { msgs: 0, cost: 0 }, tab = { chat: '', id: '', on: false, outLang: '' }, onWA = false;
let ob = { step: 0 }, keyState = {}, testRes = null, showKey = false, tabId = null;

const HOSTS = {
  openai: ['https://api.openai.com/*'], anthropic: ['https://api.anthropic.com/*'], gemini: ['https://generativelanguage.googleapis.com/*'],
  xai: ['https://api.x.ai/*'], openrouter: ['https://openrouter.ai/*'], deepl: ['https://api-free.deepl.com/*', 'https://api.deepl.com/*'],
  google: ['https://translate.googleapis.com/*']
};
// какие адреса нужны для движка (+ Google для запасного перевода)
const originsFor = (engine, fb) => [...new Set([...(HOSTS[engine] || []), ...(fb && engine !== 'google' ? HOSTS.google : [])])];
let permOk = true;
function checkPerm(done) {
  const o = originsFor(cfg.engine, cfg.fallback);
  if (!o.length || !chrome.permissions) { permOk = true; done && done(); return; }
  chrome.permissions.contains({ origins: o }, ok => { permOk = !!ok; done && done(); });
}
// ВАЖНО: chrome.permissions.request нужно вызывать прямо из обработчика клика (user gesture)
function requestPerm(engine, fb, then) {
  const o = originsFor(engine, fb);
  if (!o.length || !chrome.permissions) { then && then(true); return; }
  chrome.permissions.request({ origins: o }, ok => { then && then(!!ok); });
}
const save = patch => { cfg = { ...cfg, ...patch }; chrome.storage.local.set(patch); };
const money = c => c === 0 ? '$0' : c < 0.01 ? '<$0.01' : '$' + c.toFixed(2);
const langBtn = (field, key) => { const l = LANG[key] || [key, key, key, '🌐']; return `<button class="lang" data-lang="${field}:${esc(key)}"><span class="fl">${l[3]}</span><span class="nm">${esc(lnm(l))}</span>${I.chev}</button>`; };
const avatarBg = id => { let h = 0; for (const c of id) h = (h * 31 + c.charCodeAt(0)) % 360; return `linear-gradient(135deg,hsl(${h},62%,55%),hsl(${(h + 40) % 360},62%,42%))`; };
const toggle = (id, on, big) => `<label class="sw ${big ? 'big' : ''}"><input type="checkbox" data-sw="${id}" ${on ? 'checked' : ''}><i></i></label>`;
const seg = (id, val, opts) => `<div class="seg" data-seg="${id}">${opts.map(([v, t]) => `<button data-v="${v}" class="${val === v ? 'on' : ''}">${t}</button>`).join('')}</div>`;
function keyPill(e) {
  if (e === 'google') return '';
  const has = !!(cfg.keys || {})[e], st = keyState[e];
  if (st === 'ok') return '<span class="pill ok">'+T('✓ works')+'</span>';
  if (st === 'bad') return '<span class="pill bad">'+T('error')+'</span>';
  return has ? '<span class="pill saved">'+T('saved')+'</span>' : '<span class="pill">'+T('no key')+'</span>';
}

/* ---------- main view ---------- */
function mainView() {
  const e = ENG[cfg.engine] || ENG.google, model = (cfg.models || {})[e.id] || DEFAULT_MODELS[e.id] || '';
  const chatLangKey = tab.id && (cfg.chatLang || {})[tab.id];
  const all = cfg.scope === 'all';
  const listMap = all ? (cfg.chatOff || {}) : (cfg.enabledChats || {});
  const chatOn = tab.id ? (all ? !(cfg.chatOff || {})[tab.id] : !!(cfg.enabledChats || {})[tab.id]) : false;
  const chatItems = Object.entries(listMap).map(([id, v]) => {
    const name = typeof v === 'string' ? v : id.replace(/^title:/, ''), lg = (cfg.chatLang || {})[id];
    return `<div class="chatit"><span class="av" style="background:${avatarBg(id)}">${esc((name.trim()[0] || '?').toUpperCase())}</span><div class="tx"><b>${esc(name)}</b>${lg && LANG[lg] ? `<span>${T('writing in:')} ${LANG[lg][3]} ${esc(lnm(LANG[lg]))}</span>` : `<span>${all ? T('translation off') : T('translation on')}</span>`}</div><button class="rm" data-rm="${esc(id)}" title="${T('Remove')}">${I.x}</button></div>`;
  }).join('');
  const on = cfg.enabled;
  return `
  <div class="hdr">${LOGO}<div class="t"><h1>WA Translate</h1><div class="s">${T('Meaning-first translation')} · v${chrome.runtime.getManifest().version}</div></div>
    <div class="master ${on ? 'on' : ''}"><span class="lbl">${on ? T('On') : T('Off')}</span>${toggle('enabled', on, true)}</div></div>
  <div class="body">
    <div class="hero ${on && !(onWA && tab.chat && !chatOn) ? '' : 'off'}">
      <div class="row"><span class="dot"></span><span class="st">${!on ? T('Translation is off') : (onWA && tab.chat && !chatOn) ? T('Off in this chat') : T('Translation is on')}</span>
        <span class="chat">${onWA ? (tab.chat ? esc(tab.chat) : T('no chat open')) : T('WhatsApp Web is not open')}</span></div>
      <div class="tiles">
        <div class="tile"><div class="k">${T('Today')}</div><div class="v">${stats.msgs}</div></div>
        <div class="tile"><div class="k">${T('Engine')}</div><div class="v sm">${esc(e.name)}</div></div>
        <div class="tile"><div class="k">${T('Cost ≈')}</div><div class="v">${money(stats.cost)}</div></div>
      </div>
    </div>

    ${permOk ? '' : `<div class="card permcard"><div class="row2" style="border:0"><div class="l"><b>${T('Permission needed')}</b><span>${T('Access to the selected engine’s server ({0}). The extension contacts only that server.').replace('{0}', esc(e.name) + (cfg.fallback && e.id !== 'google' ? T(' and Google') : ''))}</span></div><button class="btn pri" data-act="grant">${T('Allow access')}</button></div></div>`}
    <div class="card">
      <div class="ch"><h2>${T('Where to translate')}</h2></div>
      <div class="row2"><div class="l"><b>${T('Mode')}</b></div>${seg('scope', cfg.scope, [['selected', T('Selected chats')], ['all', T('All chats')]])}</div>
      ${onWA && tab.chat ? `<div class="pad">${chatOn
        ? `<div class="chatnow on"><span class="ck">${I.check}</span><div class="tx"><b>${all ? T('Translation is on here') : T('On in this chat')}</b><span>${esc(tab.chat)}</span></div><button class="btn" data-act="chatoff">${T('Turn off')}</button></div>`
        : `<button class="btn pri lg bigbtn" data-act="chaton">${T('Turn on in this chat')}</button><div class="chatname">${esc(tab.chat)}${all ? T(' · currently off') : ''}</div>`}</div>`
        : `<div class="row2"><div class="l"><span>${onWA ? T('Open a chat in WhatsApp Web to turn translation on there') : T('Open a chat in WhatsApp Web (web.whatsapp.com) to turn translation on there')}</span></div></div>`}
      <div class="ch" style="padding-top:8px"><h2>${all ? T('Excluded chats') : T('Chats with translation')}</h2></div>
      ${chatItems ? `<div class="chatlist">${chatItems}</div>` : `<div class="row2" style="border:0;padding-top:2px"><div class="l"><span>${all ? T('No exclusions — every chat is translated') : T('No chats yet. Click “Turn on in this chat” in the conversation you want.')}</span></div></div>`}
    </div>

    <div class="card">
      <div class="ch"><h2>${T('Engine')}</h2>${e.link ? `<a class="getkey" href="${e.link}" target="_blank">${T('Get a key ↗')}</a>` : ''}</div>
      <div class="eng">${icoHtml(e)}<div class="n"><b>${esc(e.name)}</b><span>${esc(T(e.sub))}</span></div><button class="btn" data-act="engines">${T('Change')}</button></div>
      ${e.id !== 'google' ? `
      <div class="field"><input id="key" type="${showKey ? 'text' : 'password'}" placeholder="${esc(e.hint)} ${T('paste your API key')}" autocomplete="off" spellcheck="false" value="${esc((cfg.keys || {})[e.id] || '')}">
        ${keyPill(e.id)}<button class="eye" data-act="eye" title="${T('Show/hide')}">${showKey ? I.eyeoff : I.eye}</button></div>
      <div class="minirow">${DEFAULT_MODELS[e.id] ? `<div class="mdl"><input id="model" value="${esc(model)}" spellcheck="false" title="${T('Model')}"></div>` : '<div style="flex:1"></div>'}
        <button class="btn pri" data-act="test" id="testBtn">${T('Test')}</button></div>` : `<div class="minirow" style="padding-top:2px"><span style="color:var(--muted);font-size:12px">${T('No key needed. Translation is literal — meaning and slang get lost.')}</span></div>`}
      ${testRes ? resultHtml(testRes) : ''}
    </div>

    <div class="card">
      <div class="ch"><h2>${T('Incoming')}</h2></div>
      <div class="row2"><div class="l"><b>${T('Translate messages')}</b><span>${T('under the original, with chat context')}</span></div>${toggle('inEnabled', cfg.inEnabled)}</div>
      <div class="row2"><div class="l"><b>${T('Translate into')}</b></div>${langBtn('inLang', cfg.inLang)}</div>
    </div>

    <div class="card">
      <div class="ch"><h2>${T('Outgoing')}</h2></div>
      <div class="row2"><div class="l"><b>${T('Translate when sending')}</b><span>${T('Enter → preview → Enter')}</span></div>${toggle('outEnabled', cfg.outEnabled)}</div>
      <div class="row2"><div class="l"><b>${T('Translate into')}</b></div>${langBtn('outLang', cfg.outLang)}</div>
      ${tab.id ? `<div class="row2"><div class="l"><b>${T('This chat')}</b><span>${esc(tab.chat)}</span></div>
        <button class="lang ${chatLangKey ? '' : 'dim'}" data-lang="chat:${esc(chatLangKey || '')}"><span class="fl">${chatLangKey ? LANG[chatLangKey][3] : '🌐'}</span><span class="nm">${chatLangKey ? esc(lnm(LANG[chatLangKey])) : T('same as default')}</span>${I.chev}</button></div>` : ''}
      <div class="row2"><div class="l"><b>${T('Style')}</b></div>${seg('register', cfg.register, [['casual', T('Casual')], ['business', T('Business')]])}</div>
      <div class="row2"><div class="l"><b>${T('Mode')}</b></div>${seg('outMode', cfg.outMode, [['review', T('Preview')], ['instant', T('Instant')]])}</div>
    </div>

    <div class="foot"><span>${T('Interface language')}</span><span class="sp"></span>${seg('uiLang', cfg.uiLang || 'en', [['en', 'English'], ['ru', 'Русский']])}</div>
    <div class="foot"><span>${T('Google fallback on error')}</span><span class="sp"></span>${toggle('fallback', cfg.fallback)}</div>
    <div class="foot"><span>${T('Translation cache is stored only in this browser')}</span><span class="sp"></span><button class="btn" data-act="clearcache" id="clrBtn" style="padding:4px 10px;font-size:11.5px">${T('Clear')}</button></div>
    <div class="foot"><span>${T('Diagnostics (panel in WhatsApp + report)')}</span><span class="sp"></span>${toggle('debug', cfg.debug)}</div>
  </div>`;
}
function resultHtml(r) {
  if (r.loading) return '<div class="result loading"><span class="spin"></span>'+T('Sending a test message…')+'</div>';
  if (r.ok) return `<div class="result ok"><span class="ic">${I.check}</span><div><b>${T('Works')}</b> · ${esc(engName(r.engine))} · ${r.ms} ${T('ms')}<small>${esc(r.text)}</small></div></div>`;
  return `<div class="result bad"><span class="ic">${I.x}</span><div><b>${T('Failed')}</b><small>${esc(r.error)}</small></div></div>`;
}

/* ---------- onboarding ---------- */
function obView() {
  const s = ob.step, e = ENG[cfg.engine];
  const dots = `<div class="dots">${[0, 1, 2].map(i => `<i class="${i <= s ? 'on' : ''}"></i>`).join('')}</div>`;
  let main = '', nav = '';
  if (s === 0) {
    main = `<div class="hello-row"><img class="hello" src="icons/icon128.png" alt=""><h1>${T('Translate WhatsApp with meaning')}</h1></div><p class="lead">${T('Pick an engine. AI translates idioms and slang like a human, not word by word.')}</p>` +
      ENGINES.map(x => `<button class="item ecard ${cfg.engine === x.id ? 'sel' : ''}" data-engine="${x.id}">${icoHtml(x)}<div class="tx"><b>${esc(x.name)}${x.tag ? `<span class="tag">${T(x.tag)}</span>` : ''}</b><span>${esc(T(x.sub))}</span></div><span class="pr">${T(x.price)}</span></button>`).join('');
    nav = `<span class="sp"></span><button class="btn pri lg" data-act="next">${T('Next →')}</button>`;
  } else if (s === 1) {
    if (e.id === 'google') { ob.step = 2; return obView(); }
    main = `<h1>${T('Paste your API key')}</h1><p class="lead">${esc(e.name)} — ${esc(T(e.sub))}. ${T('The key is stored only on this device.')}</p>
      <div class="bignum"><span class="n">1</span><div><b>${T('Open the keys page')}</b><span>${T('Sign in and create a new key')}</span><br><a class="getkey" href="${e.link}" target="_blank">${T('Get a {0} key ↗').replace('{0}', esc(e.name))}</a></div></div>
      <div class="bignum"><span class="n">2</span><div><b>${T('Copy it and paste here')}</b></div></div>
      <div class="field" style="margin:4px 0 10px"><input id="key" type="${showKey ? 'text' : 'password'}" placeholder="${esc(e.hint)}" autocomplete="off" spellcheck="false" value="${esc((cfg.keys || {})[e.id] || '')}">${keyPill(e.id)}<button class="eye" data-act="eye">${showKey ? I.eyeoff : I.eye}</button></div>
      <button class="btn pri" data-act="test" id="testBtn" style="width:100%;height:36px">${T('Test key')}</button>
      <div style="margin-top:10px">${testRes ? resultHtml(testRes) : ''}</div>`.replace('class="result', 'style="margin:0" class="result');
    nav = `<button class="btn" data-act="back">←</button><span class="sp"></span><button class="skip btn" data-act="skipkey" style="border:0;background:none;color:var(--muted)">${T('Skip for now')}</button><button class="btn pri lg" data-act="next" ${keyState[e.id] === 'ok' ? '' : 'disabled'}>${T('Next →')}</button>`;
  } else {
    main = `<div class="done-ic">${I.check}</div><h1>${T('All set!')}</h1><p class="lead">${T('Open WhatsApp Web — translations will appear under messages. You can change the languages now or later.')}</p>
      <div class="card"><div class="row2"><div class="l"><b>${T('Read in')}</b></div>${langBtn('inLang', cfg.inLang)}</div><div class="row2"><div class="l"><b>${T('Write in')}</b></div>${langBtn('outLang', cfg.outLang)}</div></div>
      <div class="card"><div class="row2"><div class="l"><b>${T('Where to translate')}</b></div>${seg('scope', cfg.scope, [['selected', T('Selected')], ['all', T('All chats')]])}</div><div class="row2"><div class="l"><b>${T('Translation style')}</b></div>${seg('register', cfg.register, [['casual', T('Casual')], ['business', T('Business')]])}</div></div>`;
    nav = `<button class="btn" data-act="back">←</button><span class="sp"></span><a class="btn pri lg" data-act="finish" href="https://web.whatsapp.com" target="_blank" style="display:grid;place-items:center;text-decoration:none">${T('Open WhatsApp Web')}</a>`;
  }
  return `<div class="ob"><div class="top">${dots}<span class="uilang">${seg('uiLang', cfg.uiLang || 'en', [['en', 'EN'], ['ru', 'RU']])}</span><button class="skip" data-act="finish0">${T('Skip')}</button></div><div class="main">${main}</div><div class="nav">${nav}</div></div>`;
}

/* ---------- render and events ---------- */
function render(keepFocus) {
  $('#app').innerHTML = cfg.onboarded ? mainView() : obView();
  bind();
}
function bind() {
  document.querySelectorAll('[data-sw]').forEach(el => el.onchange = () => {
    if (el.dataset.sw === 'fallback' && el.checked) { save({ fallback: true }); requestPerm(cfg.engine, true, () => checkPerm(() => render())); return; }
    save({ [el.dataset.sw]: el.checked }); if (el.dataset.sw === 'enabled') render();
  });
  document.querySelectorAll('[data-seg]').forEach(g => g.querySelectorAll('button').forEach(b => b.onclick = () => { save({ [g.dataset.seg]: b.dataset.v }); g.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); if (g.dataset.seg === 'uiLang') { WAT_I18N.lang = b.dataset.v; document.documentElement.lang = b.dataset.v; render(); } else if (g.dataset.seg === 'scope' && cfg.onboarded) render(); }));
  document.querySelectorAll('[data-lang]').forEach(b => b.onclick = () => openLang(b.dataset.lang, b));
  document.querySelectorAll('[data-engine]').forEach(b => b.onclick = () => { const id = b.dataset.engine; save({ engine: id }); testRes = null; requestPerm(id, cfg.fallback, () => checkPerm(() => render())); });
  const key = $('#key'); if (key) key.onchange = () => { const e = cfg.engine; save({ keys: { ...cfg.keys, [e]: key.value.trim() } }); keyState[e] = null; testRes = null; render(); };
  const model = $('#model'); if (model) model.onchange = () => save({ models: { ...cfg.models, [cfg.engine]: model.value.trim() } });
  document.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => {
    const id = b.dataset.rm, f = cfg.scope === 'all' ? 'chatOff' : 'enabledChats', m = { ...(cfg[f] || {}) }; delete m[id]; save({ [f]: m }); render();
  });
  document.querySelectorAll('[data-act]').forEach(b => b.onclick = ev => act(b.dataset.act, ev));
}
function act(a, ev) {
  if (a === 'eye') { const k = $('#key'); if (k) { save({ keys: { ...cfg.keys, [cfg.engine]: k.value.trim() } }); } showKey = !showKey; render(); }
  else if (a === 'engines') openEngines();
  else if (a === 'chaton' || a === 'chatoff') toggleHere(a === 'chaton');
  else if (a === 'test') { const k = $('#key'); requestPerm(cfg.engine, false, () => runTest()); }
  else if (a === 'clearcache') chrome.runtime.sendMessage({ type: 'clearCache' }, r => { const b = $('#clrBtn'); if (b) { b.textContent = r && r.ok ? T('Cleared ✓') : T('Error'); setTimeout(() => { b.textContent = T('Clear'); }, 1800); } });
  else if (a === 'grant') requestPerm(cfg.engine, cfg.fallback, () => checkPerm(() => render()));
  else if (a === 'next') { ob.step++; testRes = null; render(); }
  else if (a === 'back') { ob.step = Math.max(0, ob.step - 1); testRes = null; render(); }
  else if (a === 'skipkey') { ob.step = 2; render(); }
  else if (a === 'finish0') { save({ onboarded: true }); render(); }
  else if (a === 'finish') { save({ onboarded: true }); }
}
function toggleHere(on) {
  const id = tab.id; if (!id) return;
  if (cfg.scope === 'all') { const m = { ...(cfg.chatOff || {}) }; if (on) delete m[id]; else m[id] = tab.chat || true; save({ chatOff: m }); }
  else { const m = { ...(cfg.enabledChats || {}) }; if (on) m[id] = tab.chat || id; else delete m[id]; save({ enabledChats: m }); }
  tab.on = on; render();
}
function runTest() {
  const k = $('#key'), m = $('#model'), e = cfg.engine;
  if (k) save({ keys: { ...cfg.keys, [e]: k.value.trim() } });
  if (m) save({ models: { ...cfg.models, [e]: m.value.trim() } });
  testRes = { loading: true }; render();
  chrome.runtime.sendMessage({ type: 'test', engine: e, key: (k && k.value.trim()) || '', model: (m && m.value.trim()) || '' }, r => {
    if (chrome.runtime.lastError || !r) testRes = { ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || T('no response') };
    else testRes = r;
    keyState[e] = testRes.ok ? 'ok' : 'bad'; render();
  });
}

/* ---------- sheets ---------- */
function openSheet(html, onMount) {
  const w = $('#sheetWrap'); w.hidden = false; w.innerHTML = `<div class="sheet">${html}</div>`;
  w.onclick = ev => { if (ev.target === w) closeSheet(); };
  onMount && onMount(w);
}
function closeSheet() { const w = $('#sheetWrap'); w.hidden = true; w.innerHTML = ''; }
function openEngines() {
  openSheet(`<div class="grab"></div><h3>${T('Translation engine')}</h3><div class="list">${ENGINES.map(x => `<button class="item ecard ${cfg.engine === x.id ? 'sel' : ''}" data-e="${x.id}">${icoHtml(x)}<div class="tx"><b>${esc(x.name)}${x.tag ? `<span class="tag">${T(x.tag)}</span>` : ''}</b><span>${esc(T(x.sub))}</span></div><span class="pr">${T(x.price)}</span></button>`).join('')}</div>`,
    w => w.querySelectorAll('[data-e]').forEach(b => b.onclick = () => { const id = b.dataset.e; save({ engine: id }); testRes = null; closeSheet(); requestPerm(id, cfg.fallback, () => checkPerm(() => render())); }));
}
function openLang(spec) {
  const i = spec.indexOf(':'), realKey = spec.slice(0, i), cur = spec.slice(i + 1), isChat = realKey === 'chat';
  const rows = l => `<button class="item ${cur === l[0] ? 'sel' : ''}" data-l="${l[0]}"><span class="fl">${l[3]}</span><span class="tx"><b>${lnm(l)}</b><span>${l[1]}</span></span><span class="ck">${I.check}</span></button>`;
  openSheet(`<div class="grab"></div><h3>${isChat ? T('Language for this chat') : realKey === 'inLang' ? T('Translate incoming into') : T('Translate outgoing into')}</h3>
    <div class="search">${I.search}<input id="q" placeholder="${T('Search language')}" autocomplete="off"></div>
    <div class="list" id="ll">${isChat ? `<button class="item ${cur ? '' : 'sel'}" data-l=""><span class="fl">🌐</span><span class="tx"><b>${T('Same as default')}</b><span>${T('the default outgoing language')}</span></span><span class="ck">${I.check}</span></button>` : ''}${LANGS.map(rows).join('')}</div>`,
    w => {
      const q = $('#q', w), bind2 = () => w.querySelectorAll('[data-l]').forEach(b => b.onclick = () => {
        const v = b.dataset.l;
        if (isChat) { const m = { ...(cfg.chatLang || {}) }; if (v) m[tab.id] = v; else delete m[tab.id]; save({ chatLang: m }); }
        else save({ [realKey]: v });
        closeSheet(); render();
      });
      bind2(); q.focus();
      q.oninput = () => { const t = q.value.toLowerCase(); $('#ll', w).innerHTML = LANGS.filter(l => !t || (l[1] + l[2] + l[4] + l[0]).toLowerCase().includes(t)).map(rows).join(''); bind2(); };
    });
}
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#sheetWrap').hidden) closeSheet(); });

/* ---------- start ---------- */
chrome.storage.local.get(null, v => {
  cfg = { ...D, ...v, keys: { ...(v.keys || {}) }, models: { ...(v.models || {}) } };
  WAT_I18N.lang = cfg.uiLang === 'ru' ? 'ru' : 'en'; document.documentElement.lang = WAT_I18N.lang;
  if (!v.v) chrome.storage.local.set({ v: 2 });
  if (v.stats && v.stats.day === new Date().toLocaleDateString('sv-SE')) stats = v.stats;
  if (!v.onboarded && v.engine && v.engine !== 'google') ob.step = 0;
  checkPerm(() => render());
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const t = tabs[0]; if (!t || !t.id) return;
    chrome.tabs.sendMessage(t.id, { type: 'stats' }, r => {
      if (chrome.runtime.lastError || !r) return;
      onWA = true; tab = { chat: r.chat || '', id: r.chatId || '', on: !!r.chatOn, outLang: r.outLang || '' }; if ($('#sheetWrap').hidden) render();
    });
  });
});
chrome.storage.onChanged.addListener(ch => { if (ch.stats && ch.stats.newValue) { stats = ch.stats.newValue; if ($('#sheetWrap').hidden && cfg.onboarded && !document.activeElement.matches('input')) render(); } });

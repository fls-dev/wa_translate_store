importScripts('translate.js');
const DEFAULTS = {
  v: 2, enabled: true, onboarded: false, engine: 'google', fallback: true,
  keys: { openai: '', anthropic: '', gemini: '', xai: '', openrouter: '', deepl: '' },
  models: { ...self.WAT.DEFAULT_MODELS },
  register: 'casual',
  inEnabled: true, inLang: 'ru', outEnabled: true, outLang: 'en', outMode: 'review', chatLang: {}, chatOff: {}, enabledChats: {}, scope: 'selected', debug: false
};
async function getCfg() {
  const L = await chrome.storage.local.get(null);
  if (!L.v) { // миграция настроек v1 (sync) → v2 (local)
    const S = await chrome.storage.sync.get(['inEnabled', 'inLang', 'outEnabled', 'outLang', 'outMode']);
    await chrome.storage.local.set({ ...DEFAULTS, ...S, ...L, v: 2 });
    return getCfg();
  }
  return { ...DEFAULTS, ...L, keys: { ...DEFAULTS.keys, ...(L.keys || {}) }, models: { ...DEFAULTS.models, ...(L.models || {}) } };
}
self.WAT.setPersist({
  load: async () => (await chrome.storage.local.get('watCache')).watCache || {},
  save: o => { const ks = Object.keys(o); if (ks.length > 1500) for (const k of ks.slice(0, ks.length - 1500)) delete o[k]; chrome.storage.local.set({ watCache: o }); }
});
const dayKey = () => new Date().toLocaleDateString('sv-SE'); // YYYY-MM-DD, локальное время
async function track(msgs, cost, req) {
  if (!msgs && !cost) return;
  const { stats } = await chrome.storage.local.get('stats');
  const st = stats && stats.day === dayKey() ? stats : { day: dayKey(), msgs: 0, cost: 0, req: 0 };
  st.msgs += msgs; st.cost += cost || 0; st.req += req || 0;
  await chrome.storage.local.set({ stats: st });
}
// Доступ к API провайдеров — опциональные разрешения: пользователь даёт их в попапе только для выбранного движка.
const HOSTS = {
  openai: ['https://api.openai.com/*'], anthropic: ['https://api.anthropic.com/*'], gemini: ['https://generativelanguage.googleapis.com/*'],
  xai: ['https://api.x.ai/*'], openrouter: ['https://openrouter.ai/*'], deepl: ['https://api-free.deepl.com/*', 'https://api.deepl.com/*'],
  google: ['https://translate.googleapis.com/*']
};
const hostOk = async id => { const o = HOSTS[id]; if (!o) return true; try { return await chrome.permissions.contains({ origins: o }); } catch (e) { return true; } };
async function guard(cfg, engine) {
  if (!(await hostOk(engine))) return 'Нет разрешения на доступ к API выбранного движка. Открой иконку расширения → «Разрешить доступ».';
  if (cfg.fallback && engine !== 'google' && !(await hostOk('google'))) cfg.fallback = false;
  return null;
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    const cfg = await getCfg();
    if (msg.type === 'cfg') { // несекретные настройки для content script
      // ключи наружу не отдаём
      const { keys, models, watCache, stats, ...pub } = cfg;
      return { ok: true, cfg: { ...pub, engineLabel: self.WAT.engineId(cfg) } };
    }
    if (msg.type === 'clearCache') { self.WAT._cache.clear(); await chrome.storage.local.remove('watCache'); return { ok: true }; }
    if (msg.type === 'incoming') {
      { const g = await guard(cfg, cfg.engine); if (g) return { ok: false, error: g }; }
      const r = await self.WAT.translateIncoming(cfg, msg.tl, msg.rows);
      let n = 0; for (const [, v] of r.results) if (v && v.t && !v.cached) n++;
      track(n, r.cost, r.usage && r.usage.req).catch(() => {});
      return { ok: true, engine: r.engine, note: r.note, results: [...r.results.entries()] };
    }
    if (msg.type === 'outgoing') {
      { const g = await guard(cfg, cfg.engine); if (g) return { ok: false, error: g }; }
      const r = await self.WAT.translateOutgoing(cfg, msg.tl, msg.text, msg.rows, msg.register || cfg.register);
      track(1, r.cost, r.usage && r.usage.req).catch(() => {});
      return { ok: true, ...r };
    }
    if (msg.type === 'test') { // кнопка «Проверить» в popup
      const c = { ...cfg, engine: msg.engine || cfg.engine, fallback: false };
      { const g = await guard(c, c.engine); if (g) return { ok: false, error: g }; }
      if (msg.key) c.keys = { ...c.keys, [c.engine]: msg.key };
      if (msg.model) c.models = { ...c.models, [c.engine]: msg.model };
      const t0 = Date.now();
      const r = await self.WAT.translateOutgoing(c, 'ru', "Hey, long time no see! We should grab a coffee and catch up — I'm totally swamped this week though.", [{ who: 'them', text: 'are you free on friday?' }], 'casual');
      return { ok: true, text: r.text, engine: r.engine, ms: Date.now() - t0 };
    }
    return { ok: false, error: 'unknown' };
  })().then(sendResponse, e => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});
